import class_pkg::*;
module config_reg_tb;


reg clk, reset, write;
reg [15:0] data_in;
address_e [2:0] address;
wire [15:0] data_out;

config_reg uut (.*);

integer correct_count = 0;
integer error_count = 0;

typedef enum {adc0_reg, adc1_reg, temp_sensor0_reg, temp_sensor1_reg,
analog_test, digital_test, amp_gain, digital_config} address_e;

reset_assoc[string] = '{
16'hFFFF, 16'h0, 16'h0, 16'h0,
16'hABCD, 16'h0, 16'h0, 16'h1};

logic [15:0] hot_ones[16] = '{
16'h0001, 16'h0002, 16'h0004, 16'h0008,
16'h0010, 16'h0020, 16'h0040,16'h0080,
16'h0100, 16'h0200, 16'h0400, 16'h0800,
16'h1000, 16'h2000, 16'h4000, 16'h8000};


//clk========================================
initial begin
    clk = 0; 
    forever begin
        #5 clk = ~clk;
    end
end

integer i;
integer j;

initial begin
    
    $display("===================================================TestBench Start===================================================");
    write = 0; reset = 0; data_in = 16'h0000;
    
    reset_and_check_all();

    //Test series2: Hot ones writing
    write = 1;  //writing data on DUT
    @(negedge clk);
    address = address.first;
    for(i = 0 ; i < address.num ; i++) begin

        for (j = 0; j < hot_ones.num ; j++)begin
            data_in = hot_ones[j];
            @(negedge clk);
            check_result();
        end

        address = address.next;
    end


    //Test series 3: Random Writing
    write = 1;  //writing data on DUT
    @(negedge clk);
    address = address.first;
    for(j = 0 ; i < address.num ; i++) begin

        repeat(64) begin
            data_in = $random % 16'hFFFF;
            @(negedge clk);
            check_result();
        end

        address = address.next;
    end

    $display("%t: At end of test error count is %0d and correct count = %0d", $time, error_count, correct_count);
    $display("====================================================TestBench End====================================================");
    $stop;

end



task reset_and_check_all;

    reset = 1;
    @(negedge clk);
    reset = 0;
    address = address.first;

    for(i=0 ; i < address.num ; i++) begin
        if(data_out  === reset_assoc[address])
            correct_count = correct_count + 1;
        else begin
            error_count = error_count + 1;
            $display("========================================================================");
            $display("Error: write = %b" , write);
            $display("address = %0h |  data_in = %b" , address , data_in);
            $display("Expected out = %d | Actual = %d", reset_assoc[address], data_out);
        end
        address = address.next;
    
        
    end

endtask


task check_result();
    
    if(data_out  === data_in)
        correct_count = correct_count + 1;
    else begin
        error_count = error_count + 1;

        $display("========================================================================");
        $display("Error: write = %b " , write);
        $display("address = %0h |  data_in = %b" , address , data_in);
        $display("Expected out = %d | Actual = %d", data_in, data_out);
    end

endtask


endmodule